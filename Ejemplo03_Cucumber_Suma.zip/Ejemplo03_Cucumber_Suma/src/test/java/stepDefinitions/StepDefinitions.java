package stepDefinitions;

import org.junit.jupiter.api.Assertions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;

public class StepDefinitions {
	
	private int numero1;
	private int numero2;
	private int resultado;
	
	@Dado("que el número {int}")
	public void que_el_numero(Integer num) {
		System.out.println(num);
		
		if (numero1 == 0) {
			numero1 = num;
		} else {
			numero2 = num;
		}
	}
	
	@Cuando("los sumo")
	public void los_sumo() {
		resultado = numero1 + numero2; 
	}
	
	
	@Entonces("el resultado debe ser {int}") 
	public void el_resultado_debe_ser(Integer esperado) {
		Assertions.assertEquals(esperado.intValue(), resultado);
	}

}
