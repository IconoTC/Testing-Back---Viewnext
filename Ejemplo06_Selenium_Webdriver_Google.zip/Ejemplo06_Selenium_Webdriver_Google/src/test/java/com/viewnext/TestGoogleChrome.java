package com.viewnext;

import java.util.concurrent.ConcurrentHashMap.KeySetView;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestGoogleChrome {
	
	private static WebDriver webDriver;
	
	
	@BeforeAll
	public static void inicio() {
		// 1.- Configurar la ruta al ejecutable de ChromeDriver
		// Para windows archivo.exe
		//System.setProperty("webdriver.chrome.driver", "/Users/anaisabelvegascaceres/Desktop/chromedriver-mac-x64/chromedriver.exe");
		
		// Para mac
		System.setProperty("webdriver.chrome.driver", "/Users/anaisabelvegascaceres/Desktop/chromedriver-mac-x64/chromedriver");
		
		// 2.- Crear la instancia
		webDriver = new ChromeDriver();
	}
	
	@AfterAll
	public static void fin() {
		if (webDriver != null)
			webDriver.quit();
	}
	
	@Test
	public void buscarGoogle() {
		
		// Abre una pagina web
		String url = "https://www.google.com/";
		webDriver.get(url);
		
		// Hay que esperar
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Localizar la caja de texto
		WebElement cajaTxt = webDriver.findElement(By.name("q"));
			
		// Escribir el texto de busqueda y enviarlo
		cajaTxt.sendKeys("Viewnext");
		cajaTxt.sendKeys(Keys.RETURN);
		
		// Hay que esperar
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// 4.- Obtener el titulo de la pagina y mostrarlo por consola
		String titulo = webDriver.getTitle();
		System.out.println("El titulo es " + titulo);
		
		Assertions.assertNotNull(titulo);
	}
	
}
