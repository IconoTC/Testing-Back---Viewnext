package com.viewnext.models;

import java.util.Properties;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;

import com.viewnext.utils.PrecioNegativoException;


public class ProductoTest {
	
	Producto producto;
	
	// Los metodos anotados como @BeforeAll y @AfterAll siempre han de ser estaticos
	// y deben estar en la clase principal
	@BeforeAll
	static void inicioClasePrueba() {
		// Iniciamos el log p.e. para almacenar el resultado de las pruebas
		System.out.println("Empezando a probar la clase ProductoTest");
	}
	
	@AfterAll
	static void finClasePrueba() {
		// Cerramos el log
		System.out.println("Hemos terminado de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioMetodoTest() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finalMetodoTest() {
		System.out.println("Prueba terminada");
	}
	
	@Nested
	@DisplayName("Test de la clase Producto")
	@Disabled
	class ProductoPruebas{
		@Test
		@DisplayName("Probando la descripcion del producto")
		void testDescripcion() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			String descripcionReal = producto.getDescripcion();
			String descripcionEsperada = "Impresora";
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}
			
		@Test
		@DisplayName("Probando el precio del producto")
		void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			//Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}
		
		@Test
		@DisplayName("Probando la igualdad de productos")
		void testIgualdadProductos() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}
		
		@Test
		@DisplayName("Probando si lanza excepcion cuando el precio es negativo")
		void testPrecioNegativoException() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Exception exception = Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-20);
			});
			
			String msgReal = exception.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			Assertions.assertEquals(msgEsperado, msgReal);
		}
	}
	
	@Nested
	@DisplayName("Probando los test de la clase Proveedor")
	class ProveedorPruebas{
		
		@Test
		void testRelacionProductoProveedor() {
			Producto producto2 = new Producto(2, "Scanner", 237.50);
			
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			
			proveedor.addProducto(producto);
			proveedor.addProducto(producto2);
			
//			Assertions.assertNotNull(proveedor.getProductos());
//			Assertions.assertEquals(2, proveedor.getProductos().size(), "El proveedor debe tener 2 productos");
//			Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
//					.filter(prod -> prod.getDescripcion().equals("Impresora"))
//					.findFirst()
//					.get()
//					.getDescripcion());
			
			// Agrupar todas las pruebas en una
			Assertions.assertAll(
					() ->  Assertions.assertNotNull(proveedor.getProductos()),
					() ->  Assertions.assertEquals(2, proveedor.getProductos().size(), "El proveedor debe tener 2 productos"),
					() ->  Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
							.filter(prod -> prod.getDescripcion().equals("Impresora"))
							.findFirst()
							.get()
							.getDescripcion())
			);
		}		
	}
	
	
	@Nested
	@DisplayName("Habilitar o deshabilitar pruebas segun el SO o el JRE")
	class SO_JRE{
		
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("Tu SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("Tu SO es Mac o Linux");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNoSOWindows() {
			System.out.println("Deshabilitado si tu SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testSoloJava8() {
			System.out.println("Probando test en Java 8");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_21)
		void testSoloJava21() {
			System.out.println("Probando test en Java 21");
		}
	}
	
	@Nested
	@DisplayName("Pruebas de System Properties")
	class SystemProperties{
		
		@Test
		void verSystemProperties() {
			Properties properties = System.getProperties();
			properties.forEach((k,v) -> System.out.println(k + ": " + v));
		}
		
		// java.version: 1.8.0_111
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.0_111")
		void testJavaVersion() {
			System.out.println("Tu version de java es 1.8.0_111");
		}
		
		// Tambien funciona con expresiones regulares
		@Test
		@EnabledIfSystemProperty(named = "java.version", matches = "1.8.*")
		void testJavaVersion2() {
			System.out.println("Tu version de java es 1.8.*");
		}
	}
	

}













