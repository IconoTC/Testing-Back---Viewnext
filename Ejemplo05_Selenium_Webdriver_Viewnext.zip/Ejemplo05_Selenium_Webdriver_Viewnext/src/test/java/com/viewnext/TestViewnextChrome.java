package com.viewnext;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestViewnextChrome {
	
	public static void main(String[] args) {
		
		// 1.- Configurar la ruta al ejecutable de ChromeDriver
		// Para windows archivo.exe
		//System.setProperty("webdriver.chrome.driver", "/Users/anaisabelvegascaceres/Desktop/chromedriver-mac-x64/chromedriver.exe");
		
		// Para mac
		System.setProperty("webdriver.chrome.driver", "/Users/anaisabelvegascaceres/Desktop/chromedriver-mac-x64/chromedriver");
		
		// 2.- Crear la instancia
		WebDriver webDriver = new ChromeDriver();
		
		// 3.- Abre una pagina web
		String url = "https://www.viewnext.com/";
		webDriver.get(url);
		
		// 4.- Obtener el titulo de la pagina y mostrarlo por consola
		String titulo = webDriver.getTitle();
		System.out.println("El titulo es " + titulo);
	}

}
