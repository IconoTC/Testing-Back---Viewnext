package com.viewnext.business;

import java.util.Optional;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.PeliculasDAO;

public class PeliculasBS {

	private PeliculasDAO dao;

	public PeliculasBS(PeliculasDAO dao) {
		super();
		this.dao = dao;
	}

	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliculaOp = dao.findAll()
			.stream()
			.filter(peli -> peli.getNombre().contains(nombre))
			.findFirst();
		
		Pelicula pelicula = null;
		if (peliculaOp.isPresent())
			pelicula = peliculaOp.get();
		
		return pelicula;
	}

}
