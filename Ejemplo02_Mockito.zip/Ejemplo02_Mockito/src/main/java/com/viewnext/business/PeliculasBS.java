package com.viewnext.business;

import java.util.List;
import java.util.Optional;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.ActoresDAO;
import com.viewnext.persistence.PeliculasDAO;

public class PeliculasBS {

	private PeliculasDAO peliculasDAO;
	private ActoresDAO actoresDAO;

	public PeliculasBS(PeliculasDAO peliculasDAO, ActoresDAO actoresDAO) {
		super();
		this.peliculasDAO = peliculasDAO;
		this.actoresDAO = actoresDAO;
	}

	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliculaOp = peliculasDAO.findAll()
			.stream()
			.filter(peli -> peli.getNombre().contains(nombre))
			.findFirst();
		
		Pelicula pelicula = null;
		if (peliculaOp.isPresent())
			pelicula = peliculaOp.get();
		
		return pelicula;
	}
	
	public Pelicula findPeliculaByNombreConActores(String nombre) {
		Pelicula pelicula = findPeliculaByNombre(nombre);
		
		if (pelicula != null) {
			List<String> reparto = actoresDAO.findActoresByPelicula(pelicula.getId());
			pelicula.setActores(reparto);
		}
		
		return pelicula;
	}
	
	public Pelicula crear(Pelicula pelicula) {
		if (!pelicula.getActores().isEmpty()) {
			actoresDAO.crearListaActores(pelicula.getActores());
		}
		return peliculasDAO.crear(pelicula);
	}

}
