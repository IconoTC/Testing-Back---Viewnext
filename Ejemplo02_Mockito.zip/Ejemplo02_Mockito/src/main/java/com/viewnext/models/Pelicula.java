package com.viewnext.models;

import java.util.ArrayList;
import java.util.List;

public class Pelicula {

	private Long id;
	private String nombre;
	private List<String> actores = new ArrayList<>();

	public Pelicula() {
		// TODO Auto-generated constructor stub
	}

	public Pelicula(Long id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<String> getActores() {
		return actores;
	}

	public void setActores(List<String> actores) {
		this.actores = actores;
	}

	@Override
	public String toString() {
		return "Pelicula [id=" + id + ", nombre=" + nombre + ", actores=" + actores + "]";
	}

}
