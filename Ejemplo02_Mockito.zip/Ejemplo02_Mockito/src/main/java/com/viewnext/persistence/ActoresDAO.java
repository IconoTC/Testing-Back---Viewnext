package com.viewnext.persistence;

import java.util.Arrays;
import java.util.List;

public class ActoresDAO {
	
	public List<String> findActoresByPelicula(Long id){
		System.out.println("Ejecutando findActoresByPelicula de ActoresDAO");
		
		return Arrays.asList("Actor 1", "Actor 2", "Actor 3");
	}
	
	
	public void crearListaActores(List<String> actores) {
		System.out.println("Ejecutando crearListaActores de ActoresDAO");
	}

}
