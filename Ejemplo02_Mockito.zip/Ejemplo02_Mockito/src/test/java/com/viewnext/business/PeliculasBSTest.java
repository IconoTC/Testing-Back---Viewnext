package com.viewnext.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.ActoresDAO;
import com.viewnext.persistence.PeliculasDAO;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSTest {
	
	@Mock
	// Para poder llamar al metodo real necesitamos tener la clase y no una interface
	PeliculasDAO peliculasDAO;
	
	@Mock
	ActoresDAO actoresDAO;
	
	@InjectMocks
	// No podemos inyectar valores en una interface, es necesario utilizar la clase
	PeliculasBS bs;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	
	@BeforeEach
	void inicioPrueba() {
		//dao = Mockito.mock(PeliculasDAO.class);
		//bs = new PeliculasBS(dao);
		
		// al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con anotaciones @ExtendWhith
		//MockitoAnnotations.openMocks(this);
	}
	
	
	@Test
	void testFindPeliculaByNombre() {
		// Crear el objeto Mock (es un objeto ficticio)
		// No se puede crear un mock de cualquier metodo, solo publicos o default
		// nunca de un metodo privado o estatico y tampoco final
		
		//PeliculasDAO dao = Mockito.mock(PeliculasDAO.class);
		//PeliculasBS bs = new PeliculasBS(dao);
		
		// Cargar datos al llamar al findAll()
		Mockito.when(peliculasDAO.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("habitacion");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(3L, pelicula.getId());
		Assertions.assertEquals("La habitacion de al lado", pelicula.getNombre());
		
	}
	
	@Test
	void testFindPeliculaByNombreConActores() {
		Mockito.when(peliculasDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actoresDAO.findActoresByPelicula(1L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("El 47");
		
		//Assertions.assertEquals(3, pelicula.getActores().size());
		
		// Con verify comprobamos que llamamos a determinados metodos del mock
		Mockito.verify(peliculasDAO).findAll();
		Mockito.verify(actoresDAO).findActoresByPelicula(1L);
	}
	
	
	@Test
	void testCapturarArgumentos() {
		Mockito.when(peliculasDAO.findAll()).thenReturn(Datos.PELICULAS);
		bs.findPeliculaByNombreConActores("La infiltrada");
		
		// Con @Captor creamos una instancia de ArgumentCaptor para capturar los argumentos
		// Tambien se puede hacer de forma programatica:
		//ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		Mockito.verify(actoresDAO).findActoresByPelicula(captor.capture());
		
		Assertions.assertEquals(2L, captor.getValue());
	}
	
	@Test
	void testCrearPelicula() {
		// 1.- Given (Preparacion)
		Pelicula peliNueva = Datos.PELICULA;
		peliNueva.setActores(Datos.ACTORES);
		
		
		// 2.- When (Accion)	
//		Mockito.doAnswer(new Answer<Pelicula>() {
//
//			@Override
//			public Pelicula answer(InvocationOnMock invocation) throws Throwable {
//				Pelicula pelicula = invocation.getArgument(0);
//				return pelicula;
//			}
//		}).when(peliculasDAO).crear(Mockito.any(Pelicula.class));
//		
//		Pelicula pelicula = bs.crear(peliNueva);
		
		//2.- When (Accion)
		// Asi retorna null Pelicula pelicula = bs.crear(peliNueva);
		Mockito.when(bs.crear(peliNueva)).thenReturn(peliNueva);

		Pelicula pelicula = bs.crear(peliNueva);
		
		// 3.- Then (Evaluar resultados)
		Assertions.assertNotNull(pelicula);
		Assertions.assertTrue(pelicula.getId() == 4);
		Assertions.assertEquals("Harry Potter", pelicula.getNombre());
	}
	
	@Test
	void testCallRealMethod() {
		Mockito.when(peliculasDAO.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.doCallRealMethod().when(actoresDAO).findActoresByPelicula(Mockito.anyLong());
		//Mockito.doCallRealMethod().when(actoresDAO).findActoresByPelicula(1L);
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("El 47");
		
		Assertions.assertTrue(pelicula.getId() == 1);
	}
	
	// Spy es un hibrido entre los mock y los objetos reales
	// Spy no funciona desde interfaces o clases abstractas, ha de ser una clase implementada
	@Test
	void testSpy() {
		PeliculasDAO peliculasDAO = Mockito.spy(PeliculasDAO.class);
		ActoresDAO actoresDAO = Mockito.spy(ActoresDAO.class);
		PeliculasBS bs = new PeliculasBS(peliculasDAO, actoresDAO);
		
		// Llamamos al metodo real
		//Mockito.when(actoresDAO.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Llamamos al mock
		Mockito.doReturn(Datos.ACTORES).when(actoresDAO).findActoresByPelicula(Mockito.anyLong());
		
		Pelicula pelicula = bs.findPeliculaByNombreConActores("El 47");
		
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
	}

}















