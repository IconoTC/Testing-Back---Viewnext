package com.viewnext.business;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.viewnext.models.Pelicula;
import com.viewnext.persistence.PeliculasDAO;

@ExtendWith(MockitoExtension.class)
public class PeliculasBSTest {
	
	@Mock
	// Para poder llamar al metodo real necesitamos tener la clase y no una interface
	PeliculasDAO dao;
	
	@InjectMocks
	// No podemos inyectar valores en una interface, es necesario utilizar la clase
	PeliculasBS bs;
	
	@BeforeEach
	void inicioPrueba() {
		//dao = Mockito.mock(PeliculasDAO.class);
		//bs = new PeliculasBS(dao);
		
		// al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con anotaciones @ExtendWhith
		//MockitoAnnotations.openMocks(this);
	}
	
	
	@Test
	void testFindPeliculaByNombre() {
		// Crear el objeto Mock (es un objeto ficticio)
		// No se puede crear un mock de cualquier metodo, solo publicos o default
		// nunca de un metodo privado o estatico y tampoco final
		
		//PeliculasDAO dao = Mockito.mock(PeliculasDAO.class);
		//PeliculasBS bs = new PeliculasBS(dao);
		
		// Cargar datos al llamar al findAll()
		Mockito.when(dao.findAll()).thenReturn(Datos.PELICULAS);
		
		Pelicula pelicula = bs.findPeliculaByNombre("habitacion");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(3L, pelicula.getId());
		Assertions.assertEquals("La habitacion de al lado", pelicula.getNombre());
		
	}

}
