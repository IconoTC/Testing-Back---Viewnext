package stepDefinitions;

import org.junit.jupiter.api.Assertions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions {
	
	private double numero1;
	private double numero2;
	private double resultado;
	private String error;
	
	@Given("Iniciamos la calculadora")
	public void iniciamos_la_calculadora() {
		resultado = 0;
		error = "";
	}
	
	@When("el usuario ingresa {double} y {double}") 
	public void el_usuario_ingresa_y(double n1, double n2) {
		this.numero1 = n1;
		this.numero2 = n2;
	}
	
	@When("realiza la operacion {word}")
	public void realiza_la_operacion(String operacion) {
		switch (operacion.toLowerCase()){
		case "suma": 
			resultado = numero1 + numero2;
			break;
		
		case "resta": 
			resultado = numero1 - numero2;
			break;
		
		case "multiplicar": 
			resultado = numero1 * numero2;
			break;
		
		case "dividir": 
			if (numero2 == 0) {
				error = "No se puede dividir por cero";
			} else {
				resultado = numero1 / numero2;
			}		
			break;
		
		default:
			error = "Esa operacion no existe";
		}
	}
	
	
	@Then("el resultado debe ser {double}") 
	public void el_resultado_debe_ser(double esperado) {
		Assertions.assertEquals(esperado, resultado);
	}
	
	@Then("debe mostrar un error {string}")  
	public void debe_mostrar_un_error(String mensajeEsperado) {
		Assertions.assertEquals(mensajeEsperado, error);
	}
	 

}
